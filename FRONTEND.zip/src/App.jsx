
    import React from 'react';
    import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import HomePage from '@/pages/HomePage';
    import LoginPage from '@/pages/LoginPage';
    import DonationPage from '@/pages/DonationPage';
    import { Toaster } from '@/components/ui/toaster';
    import { Button } from '@/components/ui/button';
    import { Home, LogIn, Gift } from 'lucide-react';

    function App() {
      return (
        <Router>
          <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 text-slate-50 flex flex-col">
            <nav className="p-4 bg-slate-900/50 backdrop-blur-md shadow-lg sticky top-0 z-50">
              <div className="container mx-auto flex justify-between items-center">
                <Link to="/" className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 hover:opacity-80 transition-opacity">
                  DonateWell
                </Link>
                <div className="space-x-2">
                  <Button variant="ghost" asChild>
                    <Link to="/"><Home className="mr-2 h-4 w-4" />Home</Link>
                  </Button>
                  <Button variant="ghost" asChild>
                    <Link to="/login"><LogIn className="mr-2 h-4 w-4" />Login</Link>
                  </Button>
                  <Button variant="ghost" asChild>
                    <Link to="/donate"><Gift className="mr-2 h-4 w-4" />Donate</Link>
                  </Button>
                </div>
              </div>
            </nav>
            <main className="flex-grow container mx-auto p-4 sm:p-6 md:p-8">
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/donate" element={<DonationPage />} />
              </Routes>
            </main>
            <Toaster />
            <footer className="p-4 bg-slate-900/50 text-center text-sm text-slate-400">
              © {new Date().getFullYear()} DonateWell. All rights reserved.
            </footer>
          </div>
        </Router>
      );
    }

    export default App;
  