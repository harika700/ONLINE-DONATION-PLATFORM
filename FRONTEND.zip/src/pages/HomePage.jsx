
    import React from 'react';
    import { useNavigate } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { HeartHandshake, Users, TrendingUp } from 'lucide-react';

    const HomePage = () => {
      const navigate = useNavigate();

      const featureVariants = {
        hidden: { opacity: 0, y: 20 },
        visible: (i) => ({
          opacity: 1,
          y: 0,
          transition: {
            delay: i * 0.2,
            duration: 0.5,
            ease: "easeOut"
          }
        })
      };

      return (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center text-center py-12"
        >
          <motion.div
            className="absolute inset-0 overflow-hidden -z-10"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1.5, delay: 0.5 }}
          >
            <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
            <div className="absolute top-1/2 left-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
            <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-6xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-orange-400"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.7, ease: "backOut" }}
          >
            Welcome to DonateWell
          </motion.h1>
          <motion.p 
            className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            Empowering change, one donation at a time. Our mission is to connect generous hearts with impactful causes, making it easy and transparent to support communities in need.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.5, type: "spring", stiffness: 120 }}
          >
            <Button 
              size="lg" 
              onClick={() => navigate('/login')}
              className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-semibold py-3 px-8 rounded-lg shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 ease-in-out"
            >
              Get Started & Login
            </Button>
          </motion.div>

          <div className="mt-20 grid md:grid-cols-3 gap-8 max-w-5xl w-full px-4">
            {[
              { icon: <HeartHandshake className="w-12 h-12 text-purple-400 mb-4" />, title: "Transparent Giving", description: "Track your donations and see the real impact you're making." },
              { icon: <Users className="w-12 h-12 text-pink-500 mb-4" />, title: "Community Focused", description: "Support a wide range of verified causes and local initiatives." },
              { icon: <TrendingUp className="w-12 h-12 text-orange-400 mb-4" />, title: "Maximize Your Impact", description: "We ensure your contributions reach those who need them most, efficiently." }
            ].map((feature, i) => (
              <motion.div
                key={i}
                custom={i}
                variants={featureVariants}
                initial="hidden"
                animate="visible"
                className="bg-slate-800/50 p-6 rounded-xl shadow-xl border border-slate-700/50 hover:shadow-2xl hover:border-purple-500/50 transition-all duration-300"
              >
                {feature.icon}
                <h3 className="text-2xl font-semibold mb-2 text-slate-100">{feature.title}</h3>
                <p className="text-slate-400">{feature.description}</p>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-20 w-full max-w-4xl">
            <h2 className="text-3xl font-bold mb-8 text-slate-100">Featured Campaigns</h2>
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div 
                className="bg-slate-800/60 p-6 rounded-lg shadow-lg border border-slate-700/60"
                whileHover={{ scale: 1.03, boxShadow: "0px 10px 20px rgba(168, 85, 247, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <img  class="w-full h-48 object-cover rounded-md mb-4" alt="Children learning in a classroom" src="https://images.unsplash.com/photo-1652407173066-6bca9753ffea" />
                <h4 className="text-xl font-semibold text-purple-400 mb-2">Education for All</h4>
                <p className="text-sm text-slate-300 mb-3">Help provide books and learning materials for underprivileged children.</p>
                <Button variant="outline" className="border-purple-500 text-purple-500 hover:bg-purple-500 hover:text-white">Learn More</Button>
              </motion.div>
              <motion.div 
                className="bg-slate-800/60 p-6 rounded-lg shadow-lg border border-slate-700/60"
                whileHover={{ scale: 1.03, boxShadow: "0px 10px 20px rgba(236, 72, 153, 0.3)" }}
                transition={{ type: "spring", stiffness: 300 }}
              >
                <img  class="w-full h-48 object-cover rounded-md mb-4" alt="Doctor attending to a patient" src="https://images.unsplash.com/photo-1579070946162-11560c3cb764" />
                <h4 className="text-xl font-semibold text-pink-500 mb-2">Healthcare Access</h4>
                <p className="text-sm text-slate-300 mb-3">Support mobile clinics bringing essential medical care to remote areas.</p>
                <Button variant="outline" className="border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white">Learn More</Button>
              </motion.div>
            </div>
          </div>

        </motion.div>
      );
    };

    export default HomePage;
  