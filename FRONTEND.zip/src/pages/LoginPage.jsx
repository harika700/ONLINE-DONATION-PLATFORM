
    import React, { useState } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { useToast } from '@/components/ui/use-toast';
    import { Mail, Lock, ArrowLeft } from 'lucide-react';

    const LoginPage = () => {
      const navigate = useNavigate();
      const { toast } = useToast();
      const [email, setEmail] = useState('');
      const [password, setPassword] = useState('');
      const [errors, setErrors] = useState({});

      const validate = () => {
        const newErrors = {};
        if (!email) newErrors.email = 'Email is required.';
        else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Email is invalid.';
        if (!password) newErrors.password = 'Password is required.';
        else if (password.length < 6) newErrors.password = 'Password must be at least 6 characters.';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        if (validate()) {
          toast({
            title: "Login Successful!",
            description: "Redirecting to donation page...",
            variant: "default",
            className: "bg-green-600 text-white border-green-700"
          });
          setTimeout(() => navigate('/donate'), 1500);
        } else {
          toast({
            title: "Validation Error",
            description: "Please check your inputs.",
            variant: "destructive",
          });
        }
      };

      return (
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 50 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center py-12"
        >
          <div className="w-full max-w-md p-8 space-y-6 bg-slate-800/70 backdrop-blur-sm rounded-xl shadow-2xl border border-slate-700/50">
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <Button variant="ghost" onClick={() => navigate('/')} className="absolute top-4 left-4 text-slate-300 hover:text-slate-100">
                <ArrowLeft className="mr-2 h-5 w-5" /> Back to Home
              </Button>
              <h2 className="text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                Login to DonateWell
              </h2>
              <p className="text-center text-slate-400 mt-2">Access your account to make a difference.</p>
            </motion.div>

            <form onSubmit={handleSubmit} className="space-y-6">
              <motion.div 
                className="space-y-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.2 }}
              >
                <Label htmlFor="email" className="text-slate-300 flex items-center">
                  <Mail className="mr-2 h-4 w-4 text-purple-400" /> Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="you@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-purple-500 focus:border-purple-500 ${errors.email ? 'border-red-500 focus:ring-red-500' : ''}`}
                />
                {errors.email && <p className="text-sm text-red-400 mt-1">{errors.email}</p>}
              </motion.div>

              <motion.div 
                className="space-y-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Label htmlFor="password" className="text-slate-300 flex items-center">
                  <Lock className="mr-2 h-4 w-4 text-pink-500" /> Password
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className={`bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-pink-500 focus:border-pink-500 ${errors.password ? 'border-red-500 focus:ring-red-500' : ''}`}
                />
                {errors.password && <p className="text-sm text-red-400 mt-1">{errors.password}</p>}
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.4 }}
              >
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-semibold py-3 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out"
                >
                  Login
                </Button>
              </motion.div>
            </form>
            <motion.p 
              className="text-center text-sm text-slate-400"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.5 }}
            >
              Don't have an account? <Link to="/signup" className="font-medium text-purple-400 hover:text-purple-300 hover:underline">Sign up</Link>
            </motion.p>
          </div>
        </motion.div>
      );
    };

    export default LoginPage;
  