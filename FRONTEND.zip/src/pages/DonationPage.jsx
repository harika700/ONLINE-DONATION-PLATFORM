
    import React, { useState, useEffect } from 'react';
    import { useNavigate, Link } from 'react-router-dom';
    import { motion } from 'framer-motion';
    import { Button } from '@/components/ui/button';
    import { Input } from '@/components/ui/input';
    import { Label } from '@/components/ui/label';
    import { Textarea } from '@/components/ui/textarea';
    import { Progress } from '@/components/ui/progress';
    import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
    import { useToast } from '@/components/ui/use-toast';
    import { DollarSign, User, Mail, MessageSquare, CreditCard, ArrowLeft, CheckCircle } from 'lucide-react';

    const presetAmounts = [10, 25, 50, 100];
    const paymentMethods = [
      { id: 'credit-card', label: 'Credit Card', icon: <CreditCard className="mr-2 h-5 w-5 text-blue-400" /> },
      { id: 'paypal', label: 'PayPal', icon: <img  class="mr-2 h-5 w-5" alt="PayPal logo" src="https://images.unsplash.com/photo-1596843720750-7de9329da5d7" /> },
    ];

    const DonationPage = () => {
      const navigate = useNavigate();
      const { toast } = useToast();
      const [amount, setAmount] = useState(presetAmounts[1]);
      const [customAmount, setCustomAmount] = useState('');
      const [name, setName] = useState('');
      const [email, setEmail] = useState('');
      const [message, setMessage] = useState('');
      const [paymentMethod, setPaymentMethod] = useState(paymentMethods[0].id);
      const [errors, setErrors] = useState({});
      const [fundraisingProgress, setFundraisingProgress] = useState(65); // Example progress

      const handleAmountSelect = (value) => {
        setAmount(value);
        setCustomAmount('');
        setErrors(prev => ({ ...prev, amount: undefined }));
      };

      const handleCustomAmountChange = (e) => {
        const value = e.target.value;
        if (/^\d*\.?\d*$/.test(value)) {
          setCustomAmount(value);
          setAmount(0); // Deselect preset
          setErrors(prev => ({ ...prev, amount: undefined }));
        }
      };

      const validate = () => {
        const newErrors = {};
        const currentAmount = customAmount ? parseFloat(customAmount) : amount;
        if (!currentAmount || currentAmount <= 0) newErrors.amount = 'Please enter a valid amount.';
        if (!name.trim()) newErrors.name = 'Name is required.';
        if (!email.trim()) newErrors.email = 'Email is required.';
        else if (!/\S+@\S+\.\S+/.test(email)) newErrors.email = 'Email is invalid.';
        if (!paymentMethod) newErrors.paymentMethod = 'Please select a payment method.';
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
      };

      const handleSubmit = (e) => {
        e.preventDefault();
        if (validate()) {
          toast({
            title: "Donation Submitted!",
            description: "Thank you for your generosity. Your contribution makes a difference.",
            className: "bg-green-600 text-white border-green-700",
            action: <CheckCircle className="text-white" />,
          });
          // Simulate API call and progress update
          setTimeout(() => {
            setFundraisingProgress(prev => Math.min(100, prev + 5));
            // Reset form or navigate away
            // navigate('/'); 
          }, 1500);
        } else {
          toast({
            title: "Validation Error",
            description: "Please correct the errors in the form.",
            variant: "destructive",
          });
        }
      };
      
      useEffect(() => {
        const timer = setTimeout(() => {
          if (fundraisingProgress < 80) { // Simulate ongoing fundraising
             setFundraisingProgress(prev => Math.min(100, prev + Math.random() * 2));
          }
        }, 3000);
        return () => clearTimeout(timer);
      }, [fundraisingProgress]);


      return (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center justify-center py-12"
        >
          <div className="w-full max-w-2xl p-8 space-y-8 bg-slate-800/70 backdrop-blur-sm rounded-xl shadow-2xl border border-slate-700/50">
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="relative"
            >
              <Button variant="ghost" onClick={() => navigate('/login')} className="absolute top-0 left-0 text-slate-300 hover:text-slate-100">
                <ArrowLeft className="mr-2 h-5 w-5" /> Back to Login
              </Button>
              <h2 className="text-3xl font-bold text-center text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                Make a Donation
              </h2>
              <p className="text-center text-slate-400 mt-2">Your support helps us create a better world.</p>
            </motion.div>

            <motion.div 
              className="space-y-2"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Label className="text-slate-300">Fundraising Progress</Label>
              <Progress value={fundraisingProgress} className="w-full [&>div]:bg-gradient-to-r [&>div]:from-purple-500 [&>div]:to-pink-500" />
              <p className="text-sm text-right text-slate-400">{fundraisingProgress}% of $10,000 goal</p>
            </motion.div>

            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Amount Selection */}
              <motion.div 
                className="space-y-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.3 }}
              >
                <Label className="text-slate-300 flex items-center"><DollarSign className="mr-2 h-5 w-5 text-green-400" /> Donation Amount</Label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {presetAmounts.map((val) => (
                    <Button
                      key={val}
                      type="button"
                      variant={amount === val ? 'default' : 'outline'}
                      onClick={() => handleAmountSelect(val)}
                      className={`${amount === val ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white' : 'border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-slate-100'} transition-all`}
                    >
                      ${val}
                    </Button>
                  ))}
                </div>
                <Input
                  type="text"
                  placeholder="Or enter custom amount"
                  value={customAmount}
                  onChange={handleCustomAmountChange}
                  className={`bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-purple-500 focus:border-purple-500 ${errors.amount ? 'border-red-500 focus:ring-red-500' : ''}`}
                />
                {errors.amount && <p className="text-sm text-red-400 mt-1">{errors.amount}</p>}
              </motion.div>

              {/* Donor Information */}
              <div className="grid md:grid-cols-2 gap-6">
                <motion.div 
                  className="space-y-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.4 }}
                >
                  <Label htmlFor="name" className="text-slate-300 flex items-center"><User className="mr-2 h-4 w-4 text-purple-400" /> Full Name</Label>
                  <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className={`bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-purple-500 focus:border-purple-500 ${errors.name ? 'border-red-500 focus:ring-red-500' : ''}`} />
                  {errors.name && <p className="text-sm text-red-400 mt-1">{errors.name}</p>}
                </motion.div>
                <motion.div 
                  className="space-y-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.45 }}
                >
                  <Label htmlFor="email" className="text-slate-300 flex items-center"><Mail className="mr-2 h-4 w-4 text-pink-500" /> Email Address</Label>
                  <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane.doe@example.com" className={`bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-pink-500 focus:border-pink-500 ${errors.email ? 'border-red-500 focus:ring-red-500' : ''}`} />
                  {errors.email && <p className="text-sm text-red-400 mt-1">{errors.email}</p>}
                </motion.div>
              </div>

              <motion.div 
                className="space-y-2"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.5 }}
              >
                <Label htmlFor="message" className="text-slate-300 flex items-center"><MessageSquare className="mr-2 h-4 w-4 text-slate-400" /> Optional Message</Label>
                <Textarea id="message" value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Your words of encouragement..." className="bg-slate-700/50 border-slate-600 placeholder-slate-500 text-slate-100 focus:ring-slate-500 focus:border-slate-500" />
              </motion.div>

              {/* Payment Method */}
              <motion.div 
                className="space-y-3"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: 0.6 }}
              >
                <Label className="text-slate-300 flex items-center"><CreditCard className="mr-2 h-5 w-5 text-sky-400" /> Payment Method</Label>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="flex flex-col sm:flex-row gap-4">
                  {paymentMethods.map((method) => (
                    <div key={method.id} className="flex items-center space-x-2">
                      <RadioGroupItem value={method.id} id={method.id} className="border-slate-600 text-purple-500 focus:ring-purple-500 data-[state=checked]:border-purple-500" />
                      <Label htmlFor={method.id} className="text-slate-300 flex items-center cursor-pointer hover:text-slate-100">
                        {method.icon} {method.label}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
                {errors.paymentMethod && <p className="text-sm text-red-400 mt-1">{errors.paymentMethod}</p>}
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.7 }}
              >
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white font-semibold py-3 rounded-lg shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 ease-in-out"
                  disabled={Object.keys(errors).some(key => errors[key])}
                >
                  Donate Now
                </Button>
              </motion.div>
            </form>

            <motion.p 
              className="text-center text-xs text-slate-500"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.8 }}
            >
              By donating, you agree to our <Link to="/terms" className="underline hover:text-slate-300">Terms of Service</Link> and <Link to="/privacy" className="underline hover:text-slate-300">Privacy Policy</Link>.
            </motion.p>
          </div>
        </motion.div>
      );
    };

    export default DonationPage;
  